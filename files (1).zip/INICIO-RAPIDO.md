# 🚀 Início Rápido - 5 Minutos

## Passo 1: Supabase (2 minutos)

1. Vá em [supabase.com](https://supabase.com) → "Start your project"
2. Crie um projeto (espere ~2min)
3. Vá em SQL Editor → Cole o conteúdo de `supabase-schema.sql` → Run
4. Vá em Settings → API → Copie:
   - `URL` 
   - `anon public key`

## Passo 2: Stripe (2 minutos)

1. Vá em [stripe.com](https://stripe.com) → Crie conta
2. Ative modo de teste (toggle no topo)
3. Vá em Developers → API Keys → Copie `Publishable key`

## Passo 3: Configurar (1 minuto)

1. Abra `config.js`
2. Cole suas credenciais:

```javascript
const CONFIG = {
  supabase: {
    url: 'https://xxxxx.supabase.co', // Cole aqui
    anonKey: 'eyJhbGc...' // Cole aqui
  },
  stripe: {
    publishableKey: 'pk_test_...' // Cole aqui
  },
  siteUrl: 'http://localhost:8000' // Ou seu domínio
};
```

## Passo 4: Testar Localmente

```bash
# Abra com um servidor local (escolha um):
python -m http.server 8000
# ou
npx serve
# ou
php -S localhost:8000
```

Acesse: `http://localhost:8000`

## Passo 5: Primeiro Produto

1. Crie um produto na Stripe:
   - Products → Add product
   - Nome: "Teste SaaS"
   - Preço: R$ 10 (recorrente mensal)
   - Copie o `Price ID`

2. No marketplace:
   - Clique em "Acessar"
   - Cadastre-se
   - Adicione produto com o Price ID

**Pronto! Seu marketplace está funcionando! 🎉**

---

## 🧪 Testar Compra

1. Abra o marketplace
2. Clique em "Comprar" no produto
3. Use cartão de teste: `4242 4242 4242 4242`
4. CVV: `123`, Data: `12/34`
5. Veja a confirmação!

---

## 📊 Ver Vendas

1. Vá no Dashboard
2. Clique na aba "Vendas"
3. Veja suas vendas e estatísticas

---

## ⚠️ Importante

Para funcionar 100%, você ainda precisa:

1. **Configurar Webhooks** (seguir README completo)
2. **Configurar Edge Functions** (opcional mas recomendado)
3. **Trocar para chaves de produção** quando lançar

---

## 🆘 Problemas?

**Erro de login:**
- Verifique se executou o SQL no Supabase

**Produtos não aparecem:**
- Verifique se marcou como "ativo" ao criar

**Checkout não funciona:**
- Você precisa configurar as Edge Functions (ver README)

---

**Pronto para lançar? Siga o README completo! 📚**
