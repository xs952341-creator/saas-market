# 🚀 SaaSMarket - Marketplace Autônomo de SaaS

Um marketplace completo e funcional para venda de SaaS com pagamentos automáticos via Stripe e gerenciamento via Supabase.

## 📋 Características

- ✅ **Totalmente autônomo** - Uma vez configurado, funciona sozinho
- 💳 **Pagamentos via Stripe** - Checkout seguro e automático
- 🗄️ **Banco de dados Supabase** - Armazenamento em tempo real
- 🔐 **Sistema de autenticação** - Login/cadastro de vendedores
- 📊 **Dashboard para vendedores** - Gerenciar produtos e ver vendas
- 🎨 **Interface moderna** - Design profissional com Tailwind CSS
- 📱 **Totalmente responsivo** - Funciona em mobile e desktop

---

## 🛠️ Configuração Inicial

### 1️⃣ Configurar o Supabase

1. Crie uma conta gratuita em [supabase.com](https://supabase.com)
2. Crie um novo projeto
3. Vá em **SQL Editor** e execute o código do arquivo `supabase-schema.sql`
4. Copie suas credenciais:
   - Vá em **Settings** → **API**
   - Copie a **URL** e a **anon public key**

### 2️⃣ Configurar o Stripe

1. Crie uma conta em [stripe.com](https://stripe.com)
2. Ative o **modo de teste** (toggle no topo direito)
3. Copie suas chaves:
   - Vá em **Developers** → **API keys**
   - Copie a **Publishable key** (começa com `pk_test_...`)
   - Copie a **Secret key** (começa com `sk_test_...`) - você vai usar depois

#### Criar produtos no Stripe:

1. Vá em **Products** → **Add product**
2. Preencha:
   - Nome: "Agente de Vendas 24h"
   - Preço: R$ 47 (recorrente mensal)
3. Salve e copie o **Price ID** (ex: `price_1SzjiVE3IKoGtVrQtt5GGccz`)
4. Copie também o **Product ID** (ex: `prod_xxxxx`)

### 3️⃣ Configurar o Projeto

1. Edite o arquivo `config.js` e substitua com suas credenciais:

```javascript
const CONFIG = {
  supabase: {
    url: 'https://seu-projeto.supabase.co',
    anonKey: 'sua-anon-key-aqui'
  },
  stripe: {
    publishableKey: 'pk_test_sua_key_aqui'
  },
  comissaoPlataforma: 10, // Sua comissão em %
  siteUrl: 'https://seu-dominio.com' // ou http://localhost:8000
};
```

### 4️⃣ Configurar Webhook do Stripe

Para que as vendas sejam registradas automaticamente:

1. Crie uma Edge Function no Supabase:
   - Instale o CLI: `npm install -g supabase`
   - Execute: `supabase functions new stripe-webhook`

2. Cole este código em `supabase/functions/stripe-webhook/index.ts`:

```typescript
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Stripe from "https://esm.sh/stripe@13.0.0"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.0"

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
})

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseKey)

serve(async (req) => {
  const signature = req.headers.get('stripe-signature')
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')

  if (!signature || !webhookSecret) {
    return new Response('Missing signature or webhook secret', { status: 400 })
  }

  try {
    const body = await req.text()
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret)

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session

      // Atualizar compra no banco
      await supabase
        .from('compras')
        .update({
          status: 'completed',
          stripe_subscription_id: session.subscription,
          comprador_email: session.customer_email,
          completed_at: new Date().toISOString()
        })
        .eq('stripe_session_id', session.id)

      console.log('Compra confirmada:', session.id)
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
      status: 200,
    })

  } catch (err) {
    console.error('Webhook error:', err.message)
    return new Response(`Webhook Error: ${err.message}`, { status: 400 })
  }
})
```

3. Deploy:
```bash
supabase functions deploy stripe-webhook --no-verify-jwt
```

4. Configure as variáveis de ambiente:
```bash
supabase secrets set STRIPE_SECRET_KEY=sk_test_sua_secret_key
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
```

5. Configure o webhook no Stripe:
   - Vá em **Developers** → **Webhooks** → **Add endpoint**
   - URL: `https://seu-projeto.supabase.co/functions/v1/stripe-webhook`
   - Eventos: Selecione `checkout.session.completed`
   - Copie o **Signing secret** e use no passo 4 acima

### 5️⃣ Criar Edge Function para Checkout

1. Crie: `supabase functions new create-checkout`

2. Cole este código em `supabase/functions/create-checkout/index.ts`:

```typescript
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Stripe from "https://esm.sh/stripe@13.0.0"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.0"

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
})

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseKey)

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { priceId, produtoId, sellerId, successUrl, cancelUrl } = await req.json()

    // Buscar produto
    const { data: produto } = await supabase
      .from('produtos')
      .select('*, sellers(*)')
      .eq('id', produtoId)
      .single()

    if (!produto) {
      throw new Error('Produto não encontrado')
    }

    // Criar sessão de checkout
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{
        price: priceId,
        quantity: 1,
      }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      // Comissão da plataforma (application_fee_amount calculado pelo Stripe Connect)
    })

    // Registrar compra pendente
    await supabase.from('compras').insert({
      produto_id: produtoId,
      seller_id: sellerId,
      stripe_session_id: session.id,
      valor: produto.preco,
      status: 'pending'
    })

    return new Response(
      JSON.stringify({ sessionId: session.id }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )
  }
})
```

3. Deploy:
```bash
supabase functions deploy create-checkout
```

---

## 🚀 Como Usar

### Para Vendedores:

1. Acesse `dashboard.html`
2. Cadastre-se com email e senha
3. Crie seus produtos no Stripe primeiro
4. Adicione produtos no dashboard com os IDs da Stripe
5. Seus produtos aparecerão automaticamente no marketplace

### Para Compradores:

1. Acesse `marketplace.html`
2. Navegue pelos produtos
3. Clique em "Comprar"
4. Complete o pagamento no Stripe
5. Receba acesso imediato

---

## 📂 Estrutura de Arquivos

```
saasmarket/
├── index.html              # Landing page
├── marketplace.html        # Listagem de produtos
├── produto.html           # Página do produto
├── dashboard.html         # Painel do vendedor
├── sucesso.html          # Confirmação de compra
├── config.js             # Configurações
└── supabase-schema.sql   # Schema do banco
```

---

## 🔒 Segurança

- ✅ Row Level Security (RLS) habilitado no Supabase
- ✅ Autenticação via Supabase Auth
- ✅ Pagamentos processados pela Stripe
- ✅ Webhooks assinados e verificados
- ✅ Nenhuma informação sensível no frontend

---

## 💰 Sistema de Comissões

A comissão da plataforma é configurada em `config.js`:

```javascript
comissaoPlataforma: 10 // 10% de cada venda
```

**Importante:** Para implementar comissões automaticamente, você precisa:

1. Configurar **Stripe Connect** para onboarding de vendedores
2. Usar `application_fee_amount` no checkout
3. Os vendedores criam conta Stripe Connect pelo seu site

---

## 🧪 Modo de Teste

Durante o desenvolvimento, use as chaves de teste da Stripe (`pk_test_...` e `sk_test_...`).

**Cartões de teste:**
- Sucesso: `4242 4242 4242 4242`
- Falha: `4000 0000 0000 0002`
- CVV: qualquer 3 dígitos
- Data: qualquer data futura

---

## 🚀 Deploy

### Opção 1: GitHub Pages (apenas frontend)
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin seu-repositorio.git
git push -u origin main
```
Habilite GitHub Pages nas configurações do repo.

### Opção 2: Vercel (recomendado)
```bash
npm install -g vercel
vercel
```

### Opção 3: Netlify
Faça upload da pasta via drag-and-drop em netlify.com

---

## 📝 Checklist de Lançamento

Antes de ir para produção:

- [ ] Substituir chaves de teste por chaves de produção
- [ ] Configurar Stripe Connect para vendedores
- [ ] Adicionar termos de uso e política de privacidade
- [ ] Configurar domínio customizado
- [ ] Testar fluxo completo de compra
- [ ] Configurar email transacional
- [ ] Adicionar analytics (Google Analytics)
- [ ] Testar em mobile

---

## 🐛 Solução de Problemas

### Erro "Failed to fetch"
- Verifique se as credenciais do Supabase estão corretas
- Certifique-se que as políticas RLS estão configuradas

### Pagamento não confirmado
- Verifique se o webhook está configurado corretamente
- Veja os logs em Stripe → Developers → Webhooks
- Veja os logs em Supabase → Edge Functions

### Produtos não aparecem
- Verifique se o campo `ativo` está `true`
- Verifique se as políticas RLS permitem leitura pública

---

## 📞 Suporte

Em caso de dúvidas:
1. Verifique a documentação da Stripe
2. Verifique a documentação do Supabase
3. Abra uma issue no GitHub

---

## 📄 Licença

MIT License - Use como quiser, inclusive para projetos comerciais.

---

## 🎯 Próximos Passos

- [ ] Implementar Stripe Connect
- [ ] Sistema de reviews
- [ ] Categorias dinâmicas
- [ ] Busca avançada
- [ ] Email marketing
- [ ] Programa de afiliados
- [ ] API pública

---

**Desenvolvido com 💜 para criadores de SaaS**
